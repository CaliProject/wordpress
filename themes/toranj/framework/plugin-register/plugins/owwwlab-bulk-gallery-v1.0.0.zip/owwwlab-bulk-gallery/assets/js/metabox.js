
;(function($){
    $(function(){
       
        var $sidebar_content = $('#owlabbulkg-config-slider-sidebar-content-box').hide(),
            $same_ratio = $('#owlabbulkg-config-slider-ratio-box').hide(),
            $cols = $('#owlabbulkg-config-slider-col-box').hide(),
            $nopadding = $('#owlabbulkg-config-slider-nopadding-box').hide(),
            $icon = $('#owlabbulkg-config-slider-icon-box').hide();

        $(document).ready(function(){
            if ( $('select[name="_owlabbulkg[layout]"]').val() == 'grid'){
                $same_ratio.fadeIn();
                $cols.fadeIn();
                $nopadding.fadeIn();
            }

            if( $('select[name="_owlabbulkg[hover]"]').val() == 'simple-icon'){
                $icon.fadeIn();
            }

            if ( $('input[name="_owlabbulkg[sidebar]"]').is(':checked')){
                $sidebar_content.fadeIn();
            }
        });

        $(document).on('change','select[name="_owlabbulkg[layout]"]',function(){

            if ( this.value != 'grid'){
                $same_ratio.fadeOut();
                $cols.fadeOut();
                $nopadding.fadeOut();
            }else{
                $same_ratio.fadeIn();
                $cols.fadeIn();
                $nopadding.fadeIn();
            }
        });

        $(document).on('change','input[name="_owlabbulkg[sidebar]"]',function(){

            if ( $(this).is(':checked')){
                $sidebar_content.fadeIn();
            }else{
                $sidebar_content.fadeOut();
            }
        });
        
        $(document).on('change','select[name="_owlabbulkg[hover]"]',function(){

            if ( this.value != 'simple-icon'){
                $icon.fadeOut();
            }else{
                $icon.fadeIn();
            }
        });   



        // Load plupload if necessary.
        var owlabbulkg_uploader;
        //if ( $('input[name="_owlabbulkg[type]"]').length > 0 && 'default' == $('input[name="_owlabbulkg[type]"]:checked').val() ) {
            owlabbulkgPlupload();
        //}

        // Conditionally show necessary fields.
        owlabbulkgConditionals();

        // Handle the meta icon helper.
        if ( 0 !== $('.owlabbulkg-helper-needed').length ) {
            $('<div class="owlabbulkg-meta-helper-overlay" />').prependTo('#owlabbulkg');
        }

        $(document).on('click', '.owlabbulkg-meta-icon', function(e){
            e.preventDefault();
            var $this     = $(this),
                container = $this.parent(),
                helper    = $this.next();
            if ( helper.is(':visible') ) {
                $('.owlabbulkg-meta-helper-overlay').remove();
                container.removeClass('owlabbulkg-helper-active');
            } else {
                if ( 0 === $('.owlabbulkg-meta-helper-overlay').length ) {
                    $('<div class="owlabbulkg-meta-helper-overlay" />').prependTo('#owlabbulkg');
                }
                container.addClass('owlabbulkg-helper-active');
            }
        });

        

        // Open up the media manager modal.
        $(document).on('click', '.owlabbulkg-media-library', function(e){
            e.preventDefault();

            // Show the modal.
            owlabbulkg_main_frame = true;
            $('#owlabbulkg-upload-ui').appendTo('body').show();
        });

        // Add the selected state to images when selected from the library view.
        $('.owlabbulkg-slider').on('click', '.thumbnail, .check, .media-modal-icon', function(e){
            e.preventDefault();
            if ( $(this).parent().parent().hasClass('owlabbulkg-in-slider') )
                return;
            if ( $(this).parent().parent().hasClass('selected') )
                $(this).parent().parent().removeClass('details selected');
            else
                $(this).parent().parent().addClass('details selected');
        });

        // Load more images into the library view.
        $(document).on('click', '.owlabbulkg-load-library', function(e){
            e.preventDefault();
            var $this = $(this);
            $this.next().css({'display' : 'inline-block', 'margin-top' : '14px', 'margin-left' : '-5px'});

            // Prepare our data to be sent via Ajax.
            var load = {
                action:  'owlabbulkg_load_library',
                offset:  parseInt($this.attr('data-owlabbulkg-offset')),
                post_id: owlabbulkg_metabox.id,
                nonce:   owlabbulkg_metabox.load_slider
            };

            // Process the Ajax response and output all the necessary data.
            $.post(
                owlabbulkg_metabox.ajax,
                load,
                function(response) {
                    $this.attr('data-owlabbulkg-offset', parseInt($this.attr('data-owlabbulkg-offset')) + 20);

                    // Append the response data.
                    if ( response && response.html && $this.hasClass('has-search') ) {
                        $('.owlabbulkg-slider').html(response.html);
                        $this.removeClass('has-search');
                    } else {
                        $('.owlabbulkg-slider').append(response.html);
                    }

                    // Remove the spinner.
                    $this.next().hide();
                },
                'json'
            );
        });

        // Load images related to the search term specified
        $(document).on('keyup keydown', '#owlabbulkg-slider-search', function(){
            var $this = $(this);
            $this.prev().css({'display' : 'inline-block', 'margin-top' : '1px', 'vertical-align' : 'middle', 'margin-right' : '4px'});

            var text     = $(this).val();
            var search   = {
                action:  'owlabbulkg_library_search',
                nonce:   owlabbulkg_metabox.library_search,
                post_id: owlabbulkg_metabox.id,
                search:  text
            };

            // Send the ajax request with a delay (500ms after the user stops typing).
            delay(function() {
                // Process the Ajax response and output all the necessary data.
                $.post(
                    owlabbulkg_metabox.ajax,
                    search,
                    function(response) {
                        // Notify the load button that we have entered a search and reset the offset counter.
                        $('.owlabbulkg-load-library').addClass('has-search').attr('data-owlabbulkg-offset', parseInt(0));

                        // Append the response data.
                        if ( response )
                            $('.owlabbulkg-slider').html(response.html);

                        // Remove the spinner.
                        $this.prev().hide();
                    },
                    'json'
                );
            }, '500');
        });

        // Process inserting images into gallery when the Insert button is pressed.
        $(document).on('click', '.owlabbulkg-media-insert', function(e){
            e.preventDefault();
            var $this = $(this),
                text  = $this.text(),
                data  = {
                    action: 'owlabbulkg_insert_slides',
                    nonce:   owlabbulkg_metabox.insert_nonce,
                    post_id: owlabbulkg_metabox.id,
                    images:  {},
                    videos:  {},
                    html:    {}
                },
                selected = false,
                video    = false,
                html     = false,
                insert_e = e;
            $this.text(owlabbulkg_metabox.inserting);

            // Loop through potential data to send when inserting images.
            // First, we loop through the selected items and add them to the data var.
            $('.owlabbulkg-media-frame').find('.attachment.selected:not(.owlabbulkg-in-slider)').each(function(i, el){
                data.images[i] = $(el).attr('data-attachment-id');
                selected       = true;
            });


            // Send the ajax request with our data to be processed.
            $.post(
                owlabbulkg_metabox.ajax,
                data,
                function(response){
                    // Set small delay before closing modal.
                    setTimeout(function(){
                        // Re-append modal to correct spot and revert text back to default.
                        append_and_hide(insert_e);
                        $this.text(text);

                        // If we have selected items, be sure to properly load first images back into view.
                        if ( selected )
                            $('.owlabbulkg-load-library').attr('data-owlabbulkg-offset', 0).addClass('has-search').trigger('click');
                    }, 500);
                },
                'json'
            );

        });

        // Change content areas and active menu states on media router click.
        $(document).on('click', '.owlabbulkg-media-frame .media-menu-item', function(e){
            e.preventDefault();
            var $this       = $(this),
                old_content = $this.parent().find('.active').removeClass('active').data('owlabbulkg-content'),
                new_content = $this.addClass('active').data('owlabbulkg-content');
            $('#owlabbulkg-' + old_content).hide();
            $('#owlabbulkg-' + new_content).show();
        });



        // Make slider items sortable.
        var slider = $('#owlabbulkg-output');

        // Use ajax to make the images sortable.
        slider.sortable({
            containment: '#owlabbulkg',
            items: 'li',
            cursor: 'move',
            forcePlaceholderSize: true,
            placeholder: 'dropzone',
            update: function(event, ui) {
                // Make ajax request to sort out items.
                var opts = {
                    url:      owlabbulkg_metabox.ajax,
                    type:     'post',
                    async:    true,
                    cache:    false,
                    dataType: 'json',
                    data: {
                        action:  'owlabbulkg_sort_images',
                        order:   slider.sortable('toArray').toString(),
                        post_id: owlabbulkg_metabox.id,
                        nonce:   owlabbulkg_metabox.sort
                    },
                    success: function(response) {
                        return;
                    },
                    error: function(xhr, textStatus ,e) {
                        return;
                    }
                };
                $.ajax(opts);
            }
        });

        // Process image removal from a slider.
        $(document).on('click', '#owlabbulkg .owlabbulkg-remove-slide', function(e){
            e.preventDefault();

            // Bail out if the user does not actually want to remove the image.
            var confirm_delete = confirm(owlabbulkg_metabox.remove);
            if ( ! confirm_delete )
                return;

            // Prepare our data to be sent via Ajax.
            var attach_id = $(this).parent().attr('id'),
                remove = {
                    action:        'owlabbulkg_remove_slide',
                    attachment_id: attach_id,
                    post_id:       owlabbulkg_metabox.id,
                    nonce:         owlabbulkg_metabox.remove_nonce
                };

            // Process the Ajax response and output all the necessary data.
            $.post(
                owlabbulkg_metabox.ajax,
                remove,
                function(response) {
                    $('#' + attach_id).fadeOut('normal', function() {
                        $(this).remove();

                        // Refresh the modal view to ensure no items are still checked if they have been removed.
                        $('.owlabbulkg-load-library').attr('data-owlabbulkg-offset', 0).addClass('has-search').trigger('click');
                    });
                },
                'json'
            );
        });

        // Open up the media modal area for modifying slider metadata.
        var owlabbulkg_main_frame_meta = false;
        $(document).on('click.owlabbulkgModify', '#owlabbulkg .owlabbulkg-modify-slide', function(e){
            e.preventDefault();
            var attach_id = $(this).parent().data('owlabbulkg-slide'),
                formfield = 'owlabbulkg-meta-' + attach_id;

            // Show the modal.
            owlabbulkg_main_frame_meta = true;
            $('#' + formfield).appendTo('body').show();

           

            // Close the modal window on user action
            var append_and_hide_meta = function(e){
                e.preventDefault();
                $('#' + formfield).appendTo('#' + attach_id).hide();
                owlabbulkg_main_frame_meta = false;
                $(document).off('click.owlabbulkgLink');
            };
            $(document).on('click.owlabbulkgIframe', '.media-modal-close, .media-modal-backdrop', append_and_hide_meta);
            $(document).off('keydown.owlabbulkgIframe').on('keydown.owlabbulkgIframe', function(e){
                if ( 27 == e.keyCode && owlabbulkg_main_frame_meta ) {
                    append_and_hide_meta(e);
                }
            });
            $(document).on('click.owlabbulkgLink', '.ed_button', function(){
                // Set custom z-index for link dialog box.
                $('#wp-link-backdrop').css('zIndex', '170100');
                $('#wp-link-wrap').css('zIndex', '171005' );
            });
        });

        // Save the slider metadata.
        $(document).on('click', '.owlabbulkg-meta-submit', function(e){
            e.preventDefault();
            var $this     = $(this),
                default_t = $this.text(),
                attach_id = $this.data('owlabbulkg-item'),
                formfield = 'owlabbulkg-meta-' + attach_id,
                meta      = {};

            // Output saving text...
            $this.text(owlabbulkg_metabox.saving);

            // Add the title since it is a special field.
            meta.caption = $('#owlabbulkg-meta-table-' + attach_id).find('textarea[name="_owlabbulkg[meta_caption]"]').val();

            // Get all meta fields and values.
            $('#owlabbulkg-meta-table-' + attach_id).find(':input').not('.ed_button').each(function(i, el){
                if ( $(this).data('owlabbulkg-meta') )
                    meta[$(this).data('owlabbulkg-meta')] = $(this).val();
            });

            // Prepare the data to be sent.
            var data = {
                action:    'owlabbulkg_save_meta',
                nonce:     owlabbulkg_metabox.save_nonce,
                attach_id: attach_id,
                post_id:   owlabbulkg_metabox.id,
                meta:      meta
            };

            $.post(
                owlabbulkg_metabox.ajax,
                data,
                function(res){
                    setTimeout(function(){
                        $('#' + formfield).appendTo('#' + attach_id).hide();
                        $this.text(default_t);
                    }, 500);
                },
                'json'
            );
        });

        // Append spinner when importing a slider.
        $(document).on('click', '#owlabbulkg-import-submit', function(e){
            $(this).next().css('display', 'inline-block');
            if ( $('#owlabbulkg-config-import-slider').val().length === 0 ) {
                e.preventDefault();
                $(this).next().hide();
                alert(owlabbulkg_metabox.import);
            }
        });

        // Polling function for typing and other user centric items.
        var delay = (function() {
            var timer = 0;
            return function(callback, ms) {
                clearTimeout(timer);
                timer = setTimeout(callback, ms);
            };
        })();

        // Close the modal window on user action.
        var owlabbulkg_main_frame = false;
        var append_and_hide = function(e){
            e.preventDefault();
            $('#owlabbulkg-upload-ui').appendTo('#owlabbulkg-upload-ui-wrapper').hide();
            owlabbulkgRefresh();
            owlabbulkg_main_frame = false;
        };
        $(document).on('click', '#owlabbulkg-upload-ui .media-modal-close, #owlabbulkg-upload-ui .media-modal-backdrop', append_and_hide);
        $(document).on('keydown', function(e){
            if ( 27 == e.keyCode && owlabbulkg_main_frame )
                append_and_hide(e);
        });

        // Function to refresh images in the slider.
        function owlabbulkgRefresh(){
            var data = {
                action:  'owlabbulkg_refresh',
                post_id: owlabbulkg_metabox.id,
                nonce:   owlabbulkg_metabox.refresh_nonce
            };

            $('.max-upload-size').after('<span class="spinner owlabbulkg-spinner owlabbulkg-spinner-refresh"></span>');
            $('.owlabbulkg-spinner-refresh').css({'display' : 'inline-block', 'margin-top' : '-3px'});

            $.post(
                owlabbulkg_metabox.ajax,
                data,
                function(res){
                    if ( res && res.success ) {
                        $('#owlabbulkg-output').html(res.success);
                        $('#owlabbulkg-output').find('.wp-editor-wrap').each(function(i, el){
                            var qt = $(el).find('.quicktags-toolbar');
                            if ( qt.length > 0 ) {
                                return;
                            }

                            var arr = $(el).attr('id').split('-'),
                                id  = arr.slice(3, -1).join('-');
                            quicktags({id: 'owlabbulkg-caption-' + id, buttons: 'strong,em,link,ul,ol,li,close'});
                            QTags._buttonsInit(); // Force buttons to initialize.
                        });

                        // Initialize any code editors that have been generated with HTML slides.
        				$('.owlabbulkg-html').find('.owlabbulkg-html-code').each(function(i, el){
        					var id = $(el).attr('id');
        					owlabbulkg_html_holder[id] = CodeMirror.fromTextArea(el, {
        						enterMode: 		'keep',
        						indentUnit: 	4,
        						electricChars:  false,
        						lineNumbers: 	true,
        						lineWrapping: 	true,
        						matchBrackets: 	true,
        						mode: 			'php',
        						smartIndent:    false,
        						tabMode: 		'shift',
        						theme:			'solarized dark'
        					});
        					owlabbulkg_html_holder[id].on('blur', function(obj){
        						$('#' + id).text(obj.getValue());
        					});
        					owlabbulkg_html_holder[id].refresh();
        				});

                        // Trigger a custom event for 3rd party scripts.
                        $('#owlabbulkg-output').trigger({ type: 'owlabbulkgRefreshed', html: res.success, id: owlabbulkg_metabox.id });
                    }

                    // Remove the spinner.
                    $('.owlabbulkg-spinner-refresh').fadeOut(300, function(){
                        $(this).remove();
                    });
                },
                'json'
            );
        }

        // Function to show conditional fields.
        function owlabbulkgConditionals() {
            var owlabbulkg_mobile_option  = $('#owlabbulkg-config-mobile');
            if ( owlabbulkg_mobile_option.is(':checked') )
                $('#owlabbulkg-config-mobile-size-box').fadeIn(300);
            owlabbulkg_mobile_option.on('change', function(){
                if ( $(this).is(':checked') )
                    $('#owlabbulkg-config-mobile-size-box').fadeIn(300);
                else
                    $('#owlabbulkg-config-mobile-size-box').fadeOut(300);
            });
        }

        // Function to initialize plupload.
        function owlabbulkgPlupload() {
            // Append the custom loading progress bar.
            $('#owlabbulkg .drag-drop-inside').append('<div class="owlabbulkg-progress-bar"><div></div></div>');


            // Prepare variables.
            owlabbulkg_uploader     = new plupload.Uploader(owlabbulkg_metabox.plupload);
            var owlabbulkg_bar      = $('#owlabbulkg .owlabbulkg-progress-bar'),
                owlabbulkg_progress = $('#owlabbulkg .owlabbulkg-progress-bar div'),
                owlabbulkg_output   = $('#owlabbulkg-output');

            // Only move forward if the uploader is present.
            if ( owlabbulkg_uploader ) {

                // Append a link to use images from the user's media library.
                $('#owlabbulkg-media-library-wrapper').append(' <a class="owlabbulkg-media-library button button-primary" href="#" title="' + owlabbulkg_metabox.slider + '" style="vertical-align: baseline;">' + owlabbulkg_metabox.slider + '</a>');


                owlabbulkg_uploader.bind('Init', function(up) {
                    var uploaddiv = $('#owlabbulkg-plupload-upload-ui');

                    // If drag and drop, make that happen.
                    if ( up.features.dragdrop && ! $(document.body).hasClass('mobile') ) {
                        uploaddiv.addClass('drag-drop');
                        $('#owlabbulkg-drag-drop-area').bind('dragover.wp-uploader', function(){
                            uploaddiv.addClass('drag-over');
                        }).bind('dragleave.wp-uploader, drop.wp-uploader', function(){
                            uploaddiv.removeClass('drag-over');
                        });
                    } else {
                        uploaddiv.removeClass('drag-drop');
                        $('#owlabbulkg-drag-drop-area').unbind('.wp-uploader');
                    }

                    // If we have an HTML4 runtime, hide the flash bypass.
                    if ( up.runtime == 'html4' )
                        $('.upload-flash-bypass').hide();
                });

                // Initialize the uploader.
                owlabbulkg_uploader.init();

                // Bind to the FilesAdded event to show the progess bar.
                owlabbulkg_uploader.bind('FilesAdded', function(up, files){
                    var hundredmb = 100 * 1024 * 1024,
                        max       = parseInt(up.settings.max_file_size, 10);

                    // Remove any errors.
                    $('#owlabbulkg-upload-error').html('');

                    // Show the progress bar.
                    $(owlabbulkg_bar).show().css('display', 'block');

                    // Upload the files.
                    plupload.each(files, function(file){
                        if ( max > hundredmb && file.size > hundredmb && up.runtime != 'html5' ) {
                            owlabbulkgUploadError( up, file, true );
                        }
                    });

                    // Refresh and start.
                    up.refresh();
                    up.start();
                });

                // Bind to the UploadProgress event to manipulate the progress bar.
                owlabbulkg_uploader.bind('UploadProgress', function(up, file){
                    $(owlabbulkg_progress).css('width', up.total.percent + '%');
                });

                // Bind to the FileUploaded event to set proper UI display for slider.
                owlabbulkg_uploader.bind('FileUploaded', function(up, file, info){
                    // Make an ajax request to generate and output the image in the slider UI.
                    $.post(
                        owlabbulkg_metabox.ajax,
                        {
                            action:  'owlabbulkg_load_image',
                            nonce:   owlabbulkg_metabox.load_image,
                            id:      info.response,
                            post_id: owlabbulkg_metabox.id
                        },
                        function(res){
                            $(owlabbulkg_output).append(res);
                            $(res).find('.wp-editor-container').each(function(i, el){
                                var id = $(el).attr('id').split('-')[3];
                                quicktags({id: 'owlabbulkg-caption-' + id, buttons: 'strong,em,link,ul,ol,li,close'});
                                QTags._buttonsInit(); // Force buttons to initialize.
                            });
                        },
                        'json'
                    );
                });

                // Bind to the UploadComplete event to hide and reset the progress bar.
                owlabbulkg_uploader.bind('UploadComplete', function(){
                    $(owlabbulkg_bar).hide().css('display', 'none');
                    $(owlabbulkg_progress).removeAttr('style');
                });

                // Bind to any errors and output them on the screen.
                owlabbulkg_uploader.bind('Error', function(up, error) {
                    var hundredmb = 100 * 1024 * 1024,
                        error_el  = $('#owlabbulkg-upload-error'),
                        max;
                    switch (error) {
                        case plupload.FAILED:
                        case plupload.FILE_EXTENSION_ERROR:
                            error_el.html('<p class="error">' + pluploadL10n.upload_failed + '</p>');
                            break;
                        case plupload.FILE_SIZE_ERROR:
                            owlabbulkgUploadError(up, error.file);
                            break;
                        case plupload.IMAGE_FORMAT_ERROR:
                            wpFileError(fileObj, pluploadL10n.not_an_image);
                            break;
                        case plupload.IMAGE_MEMORY_ERROR:
                            wpFileError(fileObj, pluploadL10n.image_memory_exceeded);
                            break;
                        case plupload.IMAGE_DIMENSIONS_ERROR:
                            wpFileError(fileObj, pluploadL10n.image_dimensions_exceeded);
                            break;
                        case plupload.GENERIC_ERROR:
                            wpQueueError(pluploadL10n.upload_failed);
                            break;
                        case plupload.IO_ERROR:
                            max = parseInt(uploader.settings.max_file_size, 10);

                            if ( max > hundredmb && fileObj.size > hundredmb )
                                wpFileError(fileObj, pluploadL10n.big_upload_failed.replace('%1$s', '<a class="uploader-html" href="#">').replace('%2$s', '</a>'));
                            else
                                wpQueueError(pluploadL10n.io_error);
                            break;
                        case plupload.HTTP_ERROR:
                            wpQueueError(pluploadL10n.http_error);
                            break;
                        case plupload.INIT_ERROR:
                            $('.media-upload-form').addClass('html-uploader');
                            break;
                        case plupload.SECURITY_ERROR:
                            wpQueueError(pluploadL10n.security_error);
                            break;
                        default:
                            wpFileError(fileObj, pluploadL10n.default_error);
                    }
                    up.refresh();
                });
            }
        }

        // Function for displaying file upload errors.
        function owlabbulkgUploadError( up, file, over100mb ) {
            var message;

            if ( over100mb )
                message = pluploadL10n.big_upload_queued.replace('%s', file.name) + ' ' + pluploadL10n.big_upload_failed.replace('%1$s', '<a class="uploader-html" href="#">').replace('%2$s', '</a>');
            else
                message = pluploadL10n.file_exceeds_size_limit.replace('%s', file.name);

            $('#owlabbulkg-upload-error').html('<p class="error">' + message + '</p>');
            up.removeFile(file);
        }
    });
}(jQuery));