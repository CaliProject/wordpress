<?php
/**
 * Posttype class.
 *
 * @since 1.0.0
 *
 * @package owwwlab-kenburn
 * @author  owwwlab
 */
class Owlabbulkg_Posttype {

    /**
     * Holds the class object.
     *
     * @since 1.0.0
     *
     * @var object
     */
    public static $instance;

    /**
     * Path to the file.
     *
     * @since 1.0.0
     *
     * @var string
     */
    public $file = __FILE__;

    /**
     * Holds the base class object.
     *
     * @since 1.0.0
     *
     * @var object
     */
    public $base;

    /**
     * Primary class constructor.
     *
     * @since 1.0.0
     */
    public function __construct() {

        // Load the base class object.
        $this->base = Owlabbulkg::get_instance();

        //post type slug
        $gallery_slug = $this->base->get_theme_option('bulk_gallery_slug','bulk-gallery');
        $post_type_slug = apply_filters( 'owlab_bulk_gallery_slug', $gallery_slug );

        // Build the labels for the post type.
        $labels = apply_filters( 'owlabbulkg_post_type_labels',
            array(
                'name'               => __( 'Gallery', 'owlabbulkg' ),
                'singular_name'      => __( 'gallery', 'owlabbulkg' ),
                'add_new'            => __( 'Add New', 'owlabbulkg' ),
                'add_new_item'       => __( 'Add New', 'owlabbulkg' ),
                'edit_item'          => __( 'Edit gallery', 'owlabbulkg' ),
                'new_item'           => __( 'New gallery', 'owlabbulkg' ),
                'view_item'          => __( 'View gallery', 'owlabbulkg' ),
                'search_items'       => __( 'Search Galleries', 'owlabbulkg' ),
                'not_found'          => __( 'No galleries found.', 'owlabbulkg' ),
                'not_found_in_trash' => __( 'No galleries found in trash.', 'owlabbulkg' ),
                'parent_item_colon'  => '',
                'menu_name'          => __( 'Bulk Gallery', 'owlabbulkg' )
            )
        );

        // Build out the post type arguments.
        $args = apply_filters( 'owlabbulkg_post_type_args',
            array(

                'labels'              => $labels,
                'public'              => true,
                'publicly_queryable'  => true,
                'exclude_from_search' => false,
                'show_ui'             => true,
                'show_in_nav_menus'   => true,
                'show_in_menu'        => true,
                'show_in_admin_bar'   => true,
                'menu_position'       => 20,
                'menu_icon'           => plugins_url( 'assets/css/images/menu-icon@2x.png', $this->base->file ),
                'can_export'          => true,
                'delete_with_user'    => false,
                'capability_type'     => 'page',
                'hierarchical'        => false,
                'has_archive'         => $post_type_slug,
                'rewrite'             => array( 'slug' => $post_type_slug ),
                'supports'            => array( 'title','thumbnail','page-attributes')
            )
        );

        // Register the post type with WordPress.
        register_post_type( 'owlabbulkg', $args );

        
        
    }

    /**
     * Returns the singleton instance of the class.
     *
     * @since 1.0.0
     *
     * @return object The owlabbulkg_Posttype object.
     */
    public static function get_instance() {

        if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Owlabbulkg_Posttype ) ) {
            self::$instance = new Owlabbulkg_Posttype();
        }

        return self::$instance;

    }

}

// Load the posttype class.
$owlabbulkg_Posttype = Owlabbulkg_Posttype::get_instance();